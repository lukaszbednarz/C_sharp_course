﻿using System;
using System.Linq;
using System.Xml.Linq;
using LearningLine.Practice;

#if !AFTER

namespace LearningLine.Practice
{
    class Program
    {
        static void Main(string[] args)
        {
            var receipts = SalesReceiptFile.Read(@"..\..\SalesReceipts.bin");

            // TODO: write the receipts data to an XML file
        }
    }
}

#endif

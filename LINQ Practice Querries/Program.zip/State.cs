﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ_Practice_Querries
{
    class State
    {

        public string Name { get; set; }

        public string PostalCode { get; set; }

        public string Capital { get; set; }

        public int Population { get; set; }

    }

}
